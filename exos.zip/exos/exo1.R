########################
#####  Exo 1 ###########
########################

# (1) Saisie des variables


# (2) Affichage d'un graphique


# (3) calcul la matrice de distance euclidienne


# (4) calcul la matrice de distance de Manhattan



# (5) calcul de la localisation la plus efficace



# (6) calcul de la localisation la plus équitable


# (7) Graphique final
